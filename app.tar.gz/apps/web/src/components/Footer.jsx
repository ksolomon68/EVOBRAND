
import React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <footer className="bg-[#0f1419] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand Section */}
          <div>
            <Link to="/" className="inline-block mb-4">
              <motion.img
                src="https://horizons-cdn.hostinger.com/f8ddb934-4ef0-4d1d-923b-d5395cd33cb2/b98337c63b696e237f54f7a827b0e0d4.png"
                alt="EVOBRAND - AI Transformation Partner"
                className="h-[36px] md:h-[48px] lg:h-[60px] w-auto object-contain drop-shadow-md"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
                loading="lazy"
              />
            </Link>
            <p className="text-gray-400 text-sm mb-4">
              AI Transformation Partner - Empowering businesses with cutting-edge AI solutions, custom applications, and intelligent automation.
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#22c8e5] transition-colors">
                <Facebook size={20} />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#22c8e5] transition-colors">
                <Twitter size={20} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#22c8e5] transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#22c8e5] transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-[#22c8e5]">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/services" className="text-gray-400 hover:text-[#22c8e5] transition-colors text-sm">Services</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-[#22c8e5] transition-colors text-sm">About</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-[#22c8e5] transition-colors text-sm">Contact</Link></li>
              <li><Link to="/resources" className="text-gray-400 hover:text-[#22c8e5] transition-colors text-sm">Resources</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-[#22c8e5]">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center space-x-2 text-gray-400 text-sm">
                <Phone size={16} className="text-[#22c8e5]" />
                <a href="tel:+12145314427" className="hover:text-[#22c8e5] transition-colors">+1 214-531-4427</a>
              </li>
              <li className="flex items-center space-x-2 text-gray-400 text-sm">
                <Mail size={16} className="text-[#22c8e5]" />
                <a href="mailto:info@evobrand.net" className="hover:text-[#22c8e5] transition-colors">info@evobrand.net</a>
              </li>
              <li className="flex items-start space-x-2 text-gray-400 text-sm">
                <MapPin size={16} className="text-[#22c8e5] mt-1" />
                <span>Dallas, Texas</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-[#22c8e5]">Newsletter</h3>
            <p className="text-gray-400 text-sm mb-4">Stay updated with AI trends and insights.</p>
            <form onSubmit={handleNewsletterSubmit} className="space-y-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email"
                className="w-full px-4 py-2 bg-[#1a2332] text-white border border-gray-700 rounded-md focus:outline-none focus:border-[#22c8e5] text-sm"
                required
              />
              <button
                type="submit"
                className="w-full px-4 py-2 bg-[#22c8e5] text-white rounded-md hover:bg-[#1ba3c0] transition-colors text-sm font-medium"
              >
                {subscribed ? 'Subscribed!' : 'Subscribe'}
              </button>
            </form>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="border-t border-gray-800 pt-8 mb-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="bg-[#1a2332] p-4 rounded-lg">
              <p className="text-xs font-semibold text-[#22c8e5]">SOC 2 Certified</p>
            </div>
            <div className="bg-[#1a2332] p-4 rounded-lg">
              <p className="text-xs font-semibold text-[#22c8e5]">GDPR Compliant</p>
            </div>
            <div className="bg-[#1a2332] p-4 rounded-lg">
              <p className="text-xs font-semibold text-[#22c8e5]">US Data Sovereignty</p>
            </div>
            <div className="bg-[#1a2332] p-4 rounded-lg">
              <p className="text-xs font-semibold text-[#22c8e5]">EU AI Act Ready</p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 pt-6 text-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} EVOBRAND. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
