
import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const HeroAnimation = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <div ref={ref} className="relative w-full flex justify-center lg:justify-end items-center">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
        transition={{ duration: 0.8, ease: "easeOut", delay: 0.3 }}
        className="relative z-10"
      >
        <motion.div
          animate={{
            y: [10, -10, 10],
            rotate: [1.5, -1.5, 1.5]
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <motion.img
            src="https://horizons-cdn.hostinger.com/f8ddb934-4ef0-4d1d-923b-d5395cd33cb2/79811baef086ea37210e7fa80552c41b.webp"
            alt="Futuristic AI Technology"
            className="w-[60%] md:w-[70%] xl:w-full max-w-lg xl:max-w-xl rounded-2xl object-cover"
            style={{
              boxShadow: "0 0 40px rgba(0, 212, 255, 0.4)",
              backdropFilter: "blur(10px)"
            }}
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
            loading="lazy"
          />
        </motion.div>
      </motion.div>
    </div>
  );
};

export default HeroAnimation;
