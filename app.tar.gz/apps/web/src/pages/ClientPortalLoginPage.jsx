
import React from 'react';
import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Lock, Mail, AlertCircle } from 'lucide-react';

const ClientPortalLoginPage = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [showRecovery, setShowRecovery] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('Login functionality not yet implemented. Please contact us for access.');
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError('');
  };

  const handleRecovery = (e) => {
    e.preventDefault();
    setError('Password recovery functionality not yet implemented. Please contact support.');
  };

  return (
    <>
      <Helmet>
        <title>Client Portal Login - EVOBRAND</title>
        <meta name="description" content="Access your EVOBRAND client portal. Secure login for clients and administrators." />
      </Helmet>

      <div className="min-h-screen bg-[#0f1419] flex items-center justify-center px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          {/* Logo */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">
              <span className="text-[#22c8e5]">EVO</span>BRAND
            </h1>
            <p className="text-gray-400">Client Portal</p>
          </div>

          {/* Login Form */}
          <div className="bg-[#1a2332] p-8 rounded-xl shadow-2xl">
            {!showRecovery ? (
              <>
                <h2 className="text-2xl font-bold text-white mb-6">Sign In</h2>
                
                {error && (
                  <div className="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-lg flex items-start space-x-3">
                    <AlertCircle className="text-red-500 flex-shrink-0 mt-0.5" size={20} />
                    <p className="text-red-400 text-sm">{error}</p>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-white font-semibold mb-2">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="your@email.com"
                        className="w-full pl-12 pr-4 py-3 bg-[#0f1419] text-white border border-gray-700 rounded-lg focus:outline-none focus:border-[#22c8e5]"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">Password</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                      <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="••••••••"
                        className="w-full pl-12 pr-4 py-3 bg-[#0f1419] text-white border border-gray-700 rounded-lg focus:outline-none focus:border-[#22c8e5]"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full px-6 py-4 bg-[#22c8e5] text-white rounded-lg font-semibold hover:bg-[#1ba3c0] transition-colors"
                  >
                    Sign In
                  </button>
                </form>

                <div className="mt-6 text-center space-y-3">
                  <button
                    onClick={() => setShowRecovery(true)}
                    className="text-[#22c8e5] hover:text-[#1ba3c0] transition-colors text-sm"
                  >
                    Forgot your password?
                  </button>
                  <p className="text-gray-400 text-sm">
                    Don't have an account?{' '}
                    <a href="/contact" className="text-[#22c8e5] hover:text-[#1ba3c0] transition-colors">
                      Contact us
                    </a>
                  </p>
                </div>
              </>
            ) : (
              <>
                <h2 className="text-2xl font-bold text-white mb-6">Password Recovery</h2>
                
                {error && (
                  <div className="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-lg flex items-start space-x-3">
                    <AlertCircle className="text-red-500 flex-shrink-0 mt-0.5" size={20} />
                    <p className="text-red-400 text-sm">{error}</p>
                  </div>
                )}

                <p className="text-gray-400 mb-6">
                  Enter your email address and we'll send you instructions to reset your password.
                </p>

                <form onSubmit={handleRecovery} className="space-y-6">
                  <div>
                    <label className="block text-white font-semibold mb-2">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="your@email.com"
                        className="w-full pl-12 pr-4 py-3 bg-[#0f1419] text-white border border-gray-700 rounded-lg focus:outline-none focus:border-[#22c8e5]"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full px-6 py-4 bg-[#22c8e5] text-white rounded-lg font-semibold hover:bg-[#1ba3c0] transition-colors"
                  >
                    Send Recovery Email
                  </button>
                </form>

                <div className="mt-6 text-center">
                  <button
                    onClick={() => {
                      setShowRecovery(false);
                      setError('');
                    }}
                    className="text-[#22c8e5] hover:text-[#1ba3c0] transition-colors text-sm"
                  >
                    Back to Sign In
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Security Notice */}
          <div className="mt-6 text-center">
            <p className="text-gray-500 text-xs">
              Secure login protected by industry-standard encryption
            </p>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default ClientPortalLoginPage;
