
import React from 'react';
import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Search, Lightbulb, Code, Rocket, TrendingUp, ChevronDown, ChevronUp } from 'lucide-react';

const HowItWorksPage = () => {
  const [openFaq, setOpenFaq] = useState(null);

  const processSteps = [
    {
      week: 'Week 1',
      phase: 'Discovery & Strategy',
      icon: <Search size={40} />,
      description: 'We dive deep into understanding your business, challenges, and goals.',
      activities: [
        'Initial consultation and needs assessment',
        'Business process analysis',
        'Goal setting and KPI definition',
        'Technology stack evaluation',
        'Project roadmap creation'
      ]
    },
    {
      week: 'Week 2-6',
      phase: 'Development & Creation',
      icon: <Code size={40} />,
      description: 'Our team builds your custom AI solution with regular check-ins and updates.',
      activities: [
        'AI model development and training',
        'Custom feature implementation',
        'Integration with existing systems',
        'Quality assurance testing',
        'Regular progress updates'
      ]
    },
    {
      week: 'Week 6-7',
      phase: 'Testing & Launch',
      icon: <Rocket size={40} />,
      description: 'Rigorous testing ensures everything works perfectly before going live.',
      activities: [
        'Comprehensive system testing',
        'User acceptance testing',
        'Performance optimization',
        'Deployment to production',
        'Team training and handoff'
      ]
    },
    {
      week: 'Ongoing',
      phase: 'Support & Optimization',
      icon: <TrendingUp size={40} />,
      description: 'Continuous monitoring and improvements to maximize your ROI.',
      activities: [
        'Performance monitoring',
        'Regular updates and improvements',
        'Technical support',
        'Feature enhancements',
        'Quarterly strategy reviews'
      ]
    }
  ];

  const serviceTimelines = [
    { service: 'Custom AI Applications', timeline: '6-12 weeks', complexity: 'High' },
    { service: 'AI Visual Content Creation', timeline: '2-4 weeks', complexity: 'Medium' },
    { service: 'Intelligent Document Generation', timeline: '4-8 weeks', complexity: 'Medium' },
    { service: 'AI Video Production', timeline: '3-6 weeks', complexity: 'Medium' },
    { service: 'WordPress & Web Development', timeline: '4-8 weeks', complexity: 'Low-Medium' }
  ];

  const faqs = [
    {
      question: 'How long does a typical project take?',
      answer: 'Project timelines vary based on complexity and scope. Simple projects like visual content creation can be completed in 2-4 weeks, while complex custom AI applications may take 6-12 weeks. We provide detailed timelines during the discovery phase.'
    },
    {
      question: 'What happens during the discovery phase?',
      answer: 'During discovery, we conduct in-depth consultations to understand your business needs, analyze your current processes, define clear goals and KPIs, evaluate your technology stack, and create a comprehensive project roadmap. This ensures we build exactly what you need.'
    },
    {
      question: 'Can I make changes during development?',
      answer: 'Yes! We use an agile approach with regular check-ins and updates. Minor adjustments can be made throughout development. Major scope changes may affect timeline and budget, which we\'ll discuss transparently.'
    },
    {
      question: 'What kind of support do you provide after launch?',
      answer: 'We offer ongoing support including performance monitoring, regular updates, technical assistance, feature enhancements, and quarterly strategy reviews. Support packages are customized based on your needs.'
    },
    {
      question: 'Do you provide training for our team?',
      answer: 'Absolutely! We provide comprehensive training during the handoff phase, including documentation, video tutorials, and live training sessions. We ensure your team is confident using the new system.'
    },
    {
      question: 'How do you ensure project success?',
      answer: 'We follow a proven process with clear milestones, regular communication, quality assurance testing, and performance metrics. Our 95% client satisfaction rate speaks to our commitment to delivering results.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>How It Works - EVOBRAND Process | AI Solutions Development</title>
        <meta name="description" content="Discover our proven process for delivering AI solutions. From discovery to launch and ongoing optimization, we ensure your project success." />
      </Helmet>

      <div className="min-h-screen bg-[#0f1419]">
        {/* Hero */}
        <section className="py-20 bg-gradient-to-br from-[#1a2332] to-[#0f1419]">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                Our Proven <span className="text-[#22c8e5]">Process</span>
              </h1>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                From concept to creation, we follow a structured approach that ensures your AI transformation is successful, on-time, and delivers measurable results.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Process Timeline */}
        <section className="py-20 bg-[#0f1419]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-white mb-12 text-center">Step-by-Step Process</h2>
            <div className="max-w-5xl mx-auto">
              {processSteps.map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                  className="relative mb-12 last:mb-0"
                >
                  {/* Timeline Line */}
                  {index < processSteps.length - 1 && (
                    <div className="absolute left-6 top-20 bottom-0 w-0.5 bg-[#22c8e5] opacity-30 hidden md:block"></div>
                  )}

                  <div className="flex flex-col md:flex-row items-start gap-6">
                    {/* Icon */}
                    <div className="flex-shrink-0 w-12 h-12 bg-[#22c8e5] rounded-full flex items-center justify-center text-white z-10">
                      {step.icon}
                    </div>

                    {/* Content */}
                    <div className="flex-1 bg-[#1a2332] p-6 rounded-xl">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                        <div>
                          <p className="text-sm text-[#22c8e5] font-semibold mb-1">{step.week}</p>
                          <h3 className="text-2xl font-bold text-white">{step.phase}</h3>
                        </div>
                      </div>
                      <p className="text-gray-400 mb-4">{step.description}</p>
                      <ul className="space-y-2">
                        {step.activities.map((activity, idx) => (
                          <li key={idx} className="flex items-start space-x-2 text-gray-300">
                            <span className="w-1.5 h-1.5 bg-[#22c8e5] rounded-full mt-2 flex-shrink-0"></span>
                            <span className="text-sm">{activity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Service Timelines */}
        <section className="py-20 bg-[#1a2332]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-white mb-12 text-center">Estimated Timelines by Service</h2>
            <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-6">
              {serviceTimelines.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-[#0f1419] p-6 rounded-xl"
                >
                  <h3 className="text-lg font-bold text-white mb-2">{item.service}</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-500">Timeline</p>
                      <p className="text-[#22c8e5] font-semibold">{item.timeline}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Complexity</p>
                      <p className="text-gray-300 font-semibold">{item.complexity}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Interactive Process Diagram */}
        <section className="py-20 bg-[#0f1419]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-white mb-12 text-center">Visual Process Flow</h2>
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {processSteps.map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="bg-gradient-to-br from-[#1a2332] to-[#22c8e5]/20 p-6 rounded-xl text-center cursor-pointer"
                  >
                    <div className="text-[#22c8e5] mb-3 flex justify-center">{step.icon}</div>
                    <p className="text-xs text-gray-400 mb-1">{step.week}</p>
                    <p className="text-sm font-bold text-white">{step.phase}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-[#1a2332]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-white mb-12 text-center">Frequently Asked Questions</h2>
            <div className="max-w-3xl mx-auto space-y-4">
              {faqs.map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-[#0f1419] rounded-xl overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === index ? null : index)}
                    className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-[#1a2332] transition-colors"
                  >
                    <span className="text-lg font-semibold text-white">{faq.question}</span>
                    {openFaq === index ? (
                      <ChevronUp className="text-[#22c8e5] flex-shrink-0" size={24} />
                    ) : (
                      <ChevronDown className="text-[#22c8e5] flex-shrink-0" size={24} />
                    )}
                  </button>
                  {openFaq === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="px-6 pb-4"
                    >
                      <p className="text-gray-400">{faq.answer}</p>
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-gradient-to-br from-[#1a2332] to-[#22c8e5]">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold text-white mb-6">Ready to Start Your Journey?</h2>
            <p className="text-xl text-white/90 mb-8">Let's discuss your project and create a custom roadmap</p>
            <a
              href="/contact"
              className="inline-block px-8 py-4 bg-white text-[#1a2332] rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Schedule Free Consultation
            </a>
          </div>
        </section>
      </div>
    </>
  );
};

export default HowItWorksPage;
