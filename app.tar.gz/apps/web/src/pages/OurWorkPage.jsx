
import React from 'react';
import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Filter, TrendingUp, Clock, DollarSign, Star } from 'lucide-react';

const OurWorkPage = () => {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedIndustry, setSelectedIndustry] = useState('all');

  const filters = ['all', 'AI Applications', 'Visual Content', 'Documents', 'Video', 'Web Development'];
  const industries = ['all', 'Technology', 'Healthcare', 'Finance', 'Retail', 'Manufacturing'];

  const portfolioItems = [
    {
      id: 1,
      title: 'AI-Powered Customer Service Bot',
      category: 'AI Applications',
      industry: 'Technology',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      metrics: { roi: '300%', timeSaved: '85%', revenue: '+$500K' },
      description: 'Automated customer support reducing response time by 90%'
    },
    {
      id: 2,
      title: 'Brand Visual Asset Library',
      category: 'Visual Content',
      industry: 'Retail',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      metrics: { roi: '250%', timeSaved: '70%', revenue: '+$200K' },
      description: 'AI-generated product visuals for e-commerce platform'
    },
    {
      id: 3,
      title: 'Legal Document Automation',
      category: 'Documents',
      industry: 'Finance',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      metrics: { roi: '400%', timeSaved: '90%', revenue: '+$750K' },
      description: 'Intelligent contract generation system'
    },
    {
      id: 4,
      title: 'Marketing Video Campaign',
      category: 'Video',
      industry: 'Healthcare',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      metrics: { roi: '180%', timeSaved: '60%', revenue: '+$150K' },
      description: 'AI-assisted video production for healthcare provider'
    },
    {
      id: 5,
      title: 'E-commerce Platform Rebuild',
      category: 'Web Development',
      industry: 'Retail',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      metrics: { roi: '220%', timeSaved: '50%', revenue: '+$300K' },
      description: 'Modern WordPress e-commerce solution'
    },
    {
      id: 6,
      title: 'Predictive Analytics Dashboard',
      category: 'AI Applications',
      industry: 'Manufacturing',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      metrics: { roi: '350%', timeSaved: '75%', revenue: '+$600K' },
      description: 'Real-time production optimization system'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      company: 'TechCorp Inc.',
      role: 'CEO',
      image: 'https://images.unsplash.com/photo-1531497684310-0f15276c39ab',
      quote: 'EVOBRAND transformed our business with their AI solutions. We saw a 300% ROI in just 6 months.',
      rating: 5
    },
    {
      name: 'Michael Chen',
      company: 'RetailPro',
      role: 'Marketing Director',
      image: 'https://images.unsplash.com/photo-1531497684310-0f15276c39ab',
      quote: 'The visual content creation service saved us thousands in production costs while improving quality.',
      rating: 5
    },
    {
      name: 'Emily Rodriguez',
      company: 'HealthFirst',
      role: 'Operations Manager',
      image: 'https://images.unsplash.com/photo-1531497684310-0f15276c39ab',
      quote: 'Their video production capabilities are outstanding. Professional results at a fraction of the cost.',
      rating: 5
    }
  ];

  const filteredPortfolio = portfolioItems.filter(item => {
    const matchesCategory = selectedFilter === 'all' || item.category === selectedFilter;
    const matchesIndustry = selectedIndustry === 'all' || item.industry === selectedIndustry;
    return matchesCategory && matchesIndustry;
  });

  return (
    <>
      <Helmet>
        <title>Our Work - EVOBRAND Portfolio | Case Studies & Success Stories</title>
        <meta name="description" content="Explore our portfolio of successful AI projects. See real results, case studies, and client testimonials from businesses we've transformed." />
      </Helmet>

      <div className="min-h-screen bg-[#0f1419]">
        {/* Hero */}
        <section className="py-20 bg-gradient-to-br from-[#1a2332] to-[#0f1419]">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                Our <span className="text-[#22c8e5]">Work</span>
              </h1>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Real projects. Real results. See how we've helped businesses transform with AI.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Filters */}
        <section className="py-8 bg-[#1a2332] sticky top-20 z-40">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="flex items-center space-x-2 overflow-x-auto pb-2 w-full md:w-auto">
                <Filter className="text-[#22c8e5] flex-shrink-0" size={20} />
                <span className="text-white font-semibold flex-shrink-0">Service:</span>
                {filters.map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setSelectedFilter(filter)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all flex-shrink-0 ${
                      selectedFilter === filter
                        ? 'bg-[#22c8e5] text-white'
                        : 'bg-[#0f1419] text-gray-400 hover:text-white'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
              <div className="flex items-center space-x-2 overflow-x-auto pb-2 w-full md:w-auto">
                <span className="text-white font-semibold flex-shrink-0">Industry:</span>
                {industries.map((industry) => (
                  <button
                    key={industry}
                    onClick={() => setSelectedIndustry(industry)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all flex-shrink-0 ${
                      selectedIndustry === industry
                        ? 'bg-[#22c8e5] text-white'
                        : 'bg-[#0f1419] text-gray-400 hover:text-white'
                    }`}
                  >
                    {industry}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Portfolio Grid */}
        <section className="py-20 bg-[#0f1419]">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPortfolio.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="bg-[#1a2332] rounded-xl overflow-hidden cursor-pointer group"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute top-4 right-4 bg-[#22c8e5] text-white px-3 py-1 rounded-full text-xs font-semibold">
                      {item.category}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                    <p className="text-gray-400 text-sm mb-4">{item.description}</p>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="bg-[#0f1419] p-2 rounded text-center">
                        <p className="text-xs text-gray-500">ROI</p>
                        <p className="text-[#22c8e5] font-bold">{item.metrics.roi}</p>
                      </div>
                      <div className="bg-[#0f1419] p-2 rounded text-center">
                        <p className="text-xs text-gray-500">Time Saved</p>
                        <p className="text-[#22c8e5] font-bold">{item.metrics.timeSaved}</p>
                      </div>
                      <div className="bg-[#0f1419] p-2 rounded text-center">
                        <p className="text-xs text-gray-500">Revenue</p>
                        <p className="text-[#22c8e5] font-bold">{item.metrics.revenue}</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500">{item.industry}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-[#1a2332]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-white mb-12 text-center">Client Testimonials</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-[#0f1419] p-6 rounded-xl"
                >
                  <div className="flex items-center space-x-4 mb-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-bold text-white">{testimonial.name}</p>
                      <p className="text-sm text-gray-400">{testimonial.role}</p>
                      <p className="text-sm text-[#22c8e5]">{testimonial.company}</p>
                    </div>
                  </div>
                  <div className="flex space-x-1 mb-3">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="text-[#ffc800] fill-current" size={16} />
                    ))}
                  </div>
                  <p className="text-gray-300 italic">"{testimonial.quote}"</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-gradient-to-br from-[#1a2332] to-[#22c8e5]">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold text-white mb-6">Start Your Project</h2>
            <p className="text-xl text-white/90 mb-8">Join our growing list of successful clients</p>
            <a
              href="/contact"
              className="inline-block px-8 py-4 bg-white text-[#1a2332] rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Get Started Today
            </a>
          </div>
        </section>
      </div>
    </>
  );
};

export default OurWorkPage;
