
import React from 'react';
import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Search, Calendar, User, ArrowRight, TrendingUp, BookOpen, Lightbulb, BarChart } from 'lucide-react';

const ResourcesPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const categories = [
    { id: 'all', label: 'All Posts', icon: <BookOpen size={20} /> },
    { id: 'ai-trends', label: 'AI Trends', icon: <TrendingUp size={20} /> },
    { id: 'case-studies', label: 'Case Studies', icon: <BarChart size={20} /> },
    { id: 'how-to', label: 'How-To Guides', icon: <Lightbulb size={20} /> },
    { id: 'industry', label: 'Industry Insights', icon: <BookOpen size={20} /> }
  ];

  const blogPosts = [
    {
      id: 1,
      title: 'The Future of AI in Business: 2026 Trends',
      category: 'ai-trends',
      excerpt: 'Explore the latest AI trends shaping business transformation in 2026 and beyond.',
      author: 'Sarah Johnson',
      date: '2026-02-10',
      image: 'https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5',
      featured: true
    },
    {
      id: 2,
      title: 'How We Reduced Client Costs by 80% with AI',
      category: 'case-studies',
      excerpt: 'A detailed case study on implementing AI automation for a manufacturing client.',
      author: 'Michael Chen',
      date: '2026-02-08',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      featured: true
    },
    {
      id: 3,
      title: 'Getting Started with AI Document Automation',
      category: 'how-to',
      excerpt: 'Step-by-step guide to implementing intelligent document generation in your business.',
      author: 'Emily Rodriguez',
      date: '2026-02-05',
      image: 'https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5',
      featured: false
    },
    {
      id: 4,
      title: 'AI in Healthcare: Opportunities and Challenges',
      category: 'industry',
      excerpt: 'Understanding the impact of AI on healthcare delivery and patient outcomes.',
      author: 'Dr. James Wilson',
      date: '2026-02-03',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      featured: false
    },
    {
      id: 5,
      title: 'Maximizing ROI with AI Visual Content',
      category: 'how-to',
      excerpt: 'Learn how to leverage AI for creating high-quality visual content at scale.',
      author: 'Sarah Johnson',
      date: '2026-02-01',
      image: 'https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5',
      featured: false
    },
    {
      id: 6,
      title: 'The Rise of Generative AI in Marketing',
      category: 'ai-trends',
      excerpt: 'How generative AI is revolutionizing marketing strategies and content creation.',
      author: 'Michael Chen',
      date: '2026-01-28',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      featured: false
    },
    {
      id: 7,
      title: 'Building Trust in AI: A Practical Guide',
      category: 'how-to',
      excerpt: 'Best practices for implementing AI solutions that your team will trust and adopt.',
      author: 'Emily Rodriguez',
      date: '2026-01-25',
      image: 'https://images.unsplash.com/photo-1678995635432-d9e89c7a8fc5',
      featured: false
    },
    {
      id: 8,
      title: 'AI Success Story: Retail Transformation',
      category: 'case-studies',
      excerpt: 'How a retail client achieved 300% ROI with our AI visual content solution.',
      author: 'Sarah Johnson',
      date: '2026-01-22',
      image: 'https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa',
      featured: false
    }
  ];

  const filteredPosts = blogPosts.filter(post => {
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredPosts = blogPosts.filter(post => post.featured);
  const postsPerPage = 6;
  const totalPages = Math.ceil(filteredPosts.length / postsPerPage);
  const startIndex = (currentPage - 1) * postsPerPage;
  const paginatedPosts = filteredPosts.slice(startIndex, startIndex + postsPerPage);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <>
      <Helmet>
        <title>Resources & Blog - EVOBRAND | AI Insights & Case Studies</title>
        <meta name="description" content="Explore AI trends, case studies, how-to guides, and industry insights. Stay updated with the latest in AI transformation." />
      </Helmet>

      <div className="min-h-screen bg-[#0f1419]">
        {/* Hero */}
        <section className="py-20 bg-gradient-to-br from-[#1a2332] to-[#0f1419]">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                Resources & <span className="text-[#22c8e5]">Insights</span>
              </h1>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
                Stay ahead with the latest AI trends, case studies, and practical guides
              </p>

              {/* Search Bar */}
              <div className="max-w-2xl mx-auto relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search articles..."
                  className="w-full pl-12 pr-4 py-4 bg-[#1a2332] text-white border border-gray-700 rounded-lg focus:outline-none focus:border-[#22c8e5]"
                />
              </div>
            </motion.div>
          </div>
        </section>

        {/* Categories */}
        <section className="py-8 bg-[#1a2332] sticky top-20 z-40">
          <div className="container mx-auto px-4">
            <div className="flex overflow-x-auto space-x-4 pb-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    setSelectedCategory(category.id);
                    setCurrentPage(1);
                  }}
                  className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all flex-shrink-0 ${
                    selectedCategory === category.id
                      ? 'bg-[#22c8e5] text-white'
                      : 'bg-[#0f1419] text-gray-400 hover:text-white'
                  }`}
                >
                  {category.icon}
                  <span>{category.label}</span>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Articles */}
        {selectedCategory === 'all' && !searchQuery && (
          <section className="py-20 bg-[#0f1419]">
            <div className="container mx-auto px-4">
              <h2 className="text-3xl font-bold text-white mb-12">Featured Articles</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {featuredPosts.map((post, index) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    whileHover={{ y: -10 }}
                    className="bg-[#1a2332] rounded-xl overflow-hidden cursor-pointer group"
                  >
                    <div className="relative h-64 overflow-hidden">
                      <img
                        src={post.image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute top-4 left-4 bg-[#22c8e5] text-white px-3 py-1 rounded-full text-xs font-semibold">
                        Featured
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-[#22c8e5] transition-colors">
                        {post.title}
                      </h3>
                      <p className="text-gray-400 mb-4">{post.excerpt}</p>
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center space-x-4">
                          <span className="flex items-center space-x-1">
                            <User size={16} />
                            <span>{post.author}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Calendar size={16} />
                            <span>{new Date(post.date).toLocaleDateString()}</span>
                          </span>
                        </div>
                        <ArrowRight className="text-[#22c8e5] group-hover:translate-x-2 transition-transform" size={20} />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Blog Posts Grid */}
        <section className="py-20 bg-[#0f1419]">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-white mb-12">
              {searchQuery ? `Search Results (${filteredPosts.length})` : 'Latest Articles'}
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {paginatedPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="bg-[#1a2332] rounded-xl overflow-hidden cursor-pointer group"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <span className="text-xs text-[#22c8e5] font-semibold uppercase">
                      {categories.find(c => c.id === post.category)?.label}
                    </span>
                    <h3 className="text-xl font-bold text-white mb-2 mt-2 group-hover:text-[#22c8e5] transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-400 text-sm mb-4">{post.excerpt}</p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span className="flex items-center space-x-1">
                        <User size={14} />
                        <span>{post.author}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Calendar size={14} />
                        <span>{new Date(post.date).toLocaleDateString()}</span>
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center space-x-2">
                {[...Array(totalPages)].map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentPage(index + 1)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      currentPage === index + 1
                        ? 'bg-[#22c8e5] text-white'
                        : 'bg-[#1a2332] text-gray-400 hover:text-white'
                    }`}
                  >
                    {index + 1}
                  </button>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Newsletter Signup */}
        <section className="py-20 bg-[#1a2332]">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-white mb-4">Stay Updated</h2>
              <p className="text-gray-400 mb-8">
                Subscribe to our newsletter for the latest AI insights, case studies, and industry trends
              </p>
              <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="flex-1 px-6 py-4 bg-[#0f1419] text-white border border-gray-700 rounded-lg focus:outline-none focus:border-[#22c8e5]"
                  required
                />
                <button
                  type="submit"
                  className="px-8 py-4 bg-[#22c8e5] text-white rounded-lg font-semibold hover:bg-[#1ba3c0] transition-colors"
                >
                  {subscribed ? 'Subscribed!' : 'Subscribe'}
                </button>
              </form>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ResourcesPage;
